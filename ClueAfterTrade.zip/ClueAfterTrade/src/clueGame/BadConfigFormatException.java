//John Aspinwall
//Zachary Zembower
package clueGame;

public class BadConfigFormatException extends Exception {

	/**
	 * 
	 */
	private static final long serialVersionUID = -2260682783508379341L;

	@Override
	public String toString() {
		return "BadConfigFormatException []";
	}
	
	
	
}
