package clueGame;

import java.util.ArrayList;

public class Solution {
	public String person, weapon, room;
		
	public Solution() {
		
	}

	public Solution(String person, String weapon, String room) {
		super();
		this.person = person;
		this.weapon = weapon;
		this.room = room;
	}
}
